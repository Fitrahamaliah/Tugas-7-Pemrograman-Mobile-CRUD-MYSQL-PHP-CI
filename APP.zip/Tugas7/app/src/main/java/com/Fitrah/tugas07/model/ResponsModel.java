package com.Fitrah.tugas07.model;

import java.util.List;

public class ResponsModel {

    String  message;
    int status ;
    List<com.Fitrah.tugas07.model.DataModel> data;

    public List<com.Fitrah.tugas07.model.DataModel> getData() {
        return data;
    }

    public void setResult(List<com.Fitrah.tugas07.model.DataModel> result) {
        this.data = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
