package com.Fitrah.tugas07.model;



public class DataModel {
    String unama, uemail, utelp, ujk, ualamat ;
    int uid ;

    public String getUnama() {
        return unama;
    }

    public void setUnama(String unama) {
        this.unama = unama;
    }

    public String getUemail() {
        return uemail;
    }

    public void setUemail(String uemail) {
        this.uemail = uemail;
    }

    public String getUtelp() {
        return utelp;
    }

    public void setUtelp(String utelp) {
        this.utelp = utelp;
    }

    public String getUjk() {
        return ujk;
    }

    public void setUjk(String ujk) {
        this.ujk = ujk;
    }

    public String getUalamat() {
        return ualamat;
    }

    public void setUalamat(String ualamat) {
        this.ualamat = ualamat;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
}
